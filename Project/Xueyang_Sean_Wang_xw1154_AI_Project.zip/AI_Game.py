#Xueyang (Sean) Wang
#XW1154
#12/12/2017
#CS4613 AI Project: Mini Camelot

import time

class Board: #basic board setup
    def __init__(self, white = None, black = None):
        self.board = [] #initialization
        for i in range(0,112):
            self.board.append("-") #empty space representation
        self.empty =  ['A1','A2','A3','B1','B2','C1','F1','G1','G2','H1','H2','H3','A12','A13','A14','B13','B14','C14',
                        'F14','G13','G14','H12','H13','H14']
        if white is None:
            self.white = ['C5','D5','E5','F5','D6','E6']
        else:
            self. white = white
        if black is None:
            self.black = ['D9',"E9",'C10','D10','E10','F10']
        else:
            self.black = black

    def print_board(self): #fill the board with pieces and print with coordinates
        for i in range(0, len(self.board)-1):
            self.board[i] = '-'

        for w_coord in self.white:
            index = coord_decode(w_coord)
            self.board[index] = 'W'
        for b_coord in self.black:
            index = coord_decode(b_coord)
            self.board[index] = 'B'
        for coord in self.empty:
            index = coord_decode(coord)
            self.board[index] = ''

        print("\tA\tB\tC\tD\tE\tF\tG\tH")
        row = 1
        prntstr = ""
        for i in range(0,len(self.board)):
            if i%8 == 0:
                if i != 0:
                    prntstr += '\t' + str(row) + '\n\n'
                    row += 1
                prntstr += str(row)
            prntstr += '\t' + self.board[i]
        print(prntstr + '\t' + str(row))

def move(board, player=None):
    moves = [] #possible coordinates to moves to
    flag = False #must capture or not

    #initialize pieces to move
    if player is None:
        pieces = board.white + board.black
    elif player == 1:
        pieces = board.white
    elif player == -1:
        pieces = board.black
    else:
        return moves

    for coord in pieces: #decode to integers
        if coord[0] == 'A':
            row_moves = [-8,-7,1,8,9] #UP, RIGHT-UP, RIGHT, DOWN, RIGHT-DOWN
        elif coord[0] == 'H':
            row_moves = [-9,-8,-1,7,8] #LEFT-UP, UP, LEFT, LEFT-DOWN, DOWN
        else:
            row_moves = [-9,-8,-7,-1,1,7,8,9] #ALL 8
        index = coord_decode(coord)

        for loc in row_moves:
            #capturing move white to black, player
            if player == 1 and coord_encode(index + loc) in board.black:
                #testing edges/boundaries where it cannot skip over
                if(not(coord_encode(index + loc)[0] == 'A' and coord[0] == 'B')) and (not(coord_encode(index + loc)[0] == 'H' and coord[0] == 'G')):
                    new_locate = index + loc + loc #twice, skip-over, space immediately available
                    if new_locate in range(0,112) and coord_encode(new_locate) not in board.black and coord_encode(new_locate) not in board.white:
                        moves.append([coord, coord_encode(new_locate), coord_encode(index + loc)])
                        flag = True
            #capturing move black to white, AI
            if player == -1 and coord_encode(index + loc) in board.white:
                if(not(coord_encode(index + loc)[0] == 'A' and coord[0] == 'B')) and (not(coord_encode(index + loc)[0] == 'H' and coord[0] == 'G')):
                    new_locate = index + loc + loc
                    if new_locate in range(0,112) and coord_encode(new_locate) not in board.black and coord_encode(new_locate) not in board.white:
                        moves.append([coord, coord_encode(new_locate), coord_encode(index + loc)])
                        flag = True
            #cantering move white to white, player
            if player == 1 and coord_encode(index + loc) in board.white:
                if(not(coord_encode(index + loc)[0] == 'A' and coord[0] == 'B')) and (not(coord_encode(index + loc)[0] == 'H' and coord[0] == 'G')):
                    new_locate = index + loc + loc
                    if new_locate in range(0,112) and coord_encode(new_locate) not in board.black and coord_encode(new_locate) not in board.white:
                        moves.append([coord,coord_encode(new_locate), coord_encode(index + loc)])
            #cantering move black to black, AI
            if player == -1 and coord_encode(index + loc) in board.black:
                if(not(coord_encode(index + loc)[0] == 'A' and coord[0] == 'B')) and (not(coord_encode(index + loc)[0] == 'H' and coord[0] == 'G')):
                    new_locate = index + loc + loc
                    if new_locate in range(0,112) and coord_encode(new_locate) not in board.black and coord_encode(new_locate) not in board.white:
                        moves.append([coord,coord_encode(new_locate), coord_encode(index+loc)])
            #plain move for all
            if index + loc in range(0, 112) and coord_encode(index + loc) not in board.empty and coord_encode(index + loc) not in board.white and coord_encode(index + loc) not in board.black:
                moves.append([coord, coord_encode(index + loc)])

    if flag: #if capture, must perform capture moves
        temp = []
        for element in moves:
            if len(element) == 3: #either capture or cantering
                if player == 1 and element[2] in board.black: #if white, then capture has to be black
                    temp.append(element)
                if player == -1 and element[2] in board.white: #if black, then capture has to be white
                    temp.append(element)
        moves = list(temp)
    return moves

def player_move(board):
    global successive #more than one move
    #print(move(g, 1))
    if successive:
        print("Do you want to make successive moves?(Y/N)")
        cont = input()
        if cont.upper() != 'Y':
            successive = False
            return

    print("Please enter the coordinate of the piece you wish to move")
    select = input()
    print("Please enter the coordinate of where to place it!")
    dest = input()
    print("Remember, you have to perform capturing move when available!"
          "Please enter the coordinate of the enemy to capture or the coordinate of the friendly to canter!"
          "If not, please press 'enter'") #plain move
    remove = input()

    coordinate = []
    coordinate.append(select)
    coordinate.append(dest)
    if remove != '': #if capturing move or not
        coordinate.append(remove)

    #print(coordinate)
    if coordinate in move(g,1):
        for piece in range(0,len(board.white)): #movement
            if board.white[piece] == coordinate[0]:
                board.white[piece] = coordinate[1]
        if len(coordinate) == 3: #capturing move or cantering
            successive = True
            if coordinate[2] in board.black: #if removal is a black piece
                board.black.remove(coordinate[2])
        else:
            successive = False
    else: #prompt for input again
        print("That is not an acceptable move! Try again...")
        player_move(board)

def ai_move(board, given_move):
    if given_move in move(board,-1):
        for p in range(0,len(board.black)): #movement
            if board.black[p] == given_move[0]:
                board.black[p] = given_move[1]
        if len(given_move) == 3: #capturing or cantering
            if given_move[2] not in board.black:
                board.white.remove(given_move[2])
    else: #error, cannot move
        print("Error - AI moves")

def ab_search(board, depth):
    global maxD
    global Nodes
    global maxP
    global minP
    global start_time
    global depth_limit
    global u_value
    #Initialization
    start_time = float(time.time())
    Nodes += 1
    alpha = -u_value
    beta = u_value
    flag = None #capturing move, must return

    possible_moves = move(board,-1)
    moves_and_val = {}

    for m in range(0, len(possible_moves)):
        new_move = possible_moves[m]
        new_board = Board(list(board.white), list(board.black))  # search tree, assume such move is made
        for b in range(0, len(new_board.black)): #movements
            if new_board.black[b] == new_move[0]:
                new_board.black[b] = new_move[1]
        if len(new_move) == 3: #capturing move or cantering
            flag = new_move
            if new_move[2] not in board.black:
                new_board.white.remove(new_move[2])
        value = maxV(new_board,alpha,beta,depth+1) #pruning
        moves_and_val[m] = value

    best = min(moves_and_val, key = moves_and_val.get) #selecting values
    finish_time = float(time.time())

    print("Time:", finish_time - start_time) #print total time spent in AB search
    print("Utility:",int(moves_and_val[best])) #print best evaluated number
    if flag is None:
        return possible_moves[best]
    else:
        return flag

def maxV(board, alpha, beta, depth): #player alpha value
    global maxD
    global Nodes
    global maxP
    global minP
    global u_value
    Nodes += 1
    maxD = max(maxD, depth)

    if terminate(board, depth):
        return u_eval(board)
    value = -u_value
    possible_moves = move(board, 1)
    for moves in possible_moves:
        new_board = Board(list(board.white), list(board.black))
        for p in range(0, len(new_board.white)):
            if new_board.white[p] == moves[0]:
                new_board.white[p] = moves[1]
        if len(moves) == 3:
            if moves[2] not in new_board.white:
                new_board.black.remove(moves[2])
        value = max(value,minV(new_board,alpha,beta,depth+1))
        if value >= beta:
            maxP += 1
            return value
        alpha = max(alpha,value)
    return value

def minV(board, alpha, beta, depth): #AI beta value
    global maxD
    global Nodes
    global maxP
    global minP
    global u_value

    Nodes += 1
    maxD = max(maxD, depth)

    if terminate(board, depth):
        return u_eval(board)
    value = u_value
    possible_moves = move(board, -1)
    for moves in possible_moves:
        new_board = Board(list(board.white), list(board.black))
        for p in range(0, len(new_board.black)):
            if new_board.black[p] == moves[0]:
                new_board.black[p] = moves[1]
        if len(moves) == 3:
            if moves[2] not in new_board.black:
                new_board.white.remove(moves[2])
        value = min(value, maxV(new_board, alpha, beta, depth + 1))
        if value <= alpha:
            minP += 1
            return value
        beta = min(beta, value)
    return value

def coord_decode(coord): #decoding player location on grid into integer
    coord_dict = {'A':0,'B':1,'C':2,'D':3,'E':4,'F':5,'G':6,'H':7}
    if len(coord)>3 or coord[0] not in coord_dict.keys():
        print("Error, coordinate not found")
    else:
        index = (int(coord[1:])*8) + coord_dict[coord[0]]
        return index-8

def coord_encode(index): #encoding player location on grid into string
    index_dict = {0:'A',1:'B',2:'C',3:'D',4:'E',5:'F',6:'G',7:'H'}
    row = int(index/8)+1
    col = index_dict[index%8]
    return str(col) + str(row)

def terminate(board, depth): #terminal stage
    global start_time #time
    global depth_limit #depth

    current_time = float(time.time()) #current running
    if depth != 0 and (current_time - start_time) >= 9.9:
        return True #terminate: too long
    if depth >= depth_limit:
        return True #terminate: too deep
    state = win(board) #check winning conditions
    if state == 1 or state == -1 or state == 2:
        return True #terminate: winner found or draw
    return False

def win(board): #checking winning conditions
    white_win = ['D14','E14'] #white goals
    black_win = ['D1','E1'] #black goals

    if len(board.white) == 1 and len(board.black) == 1:
        return 2 #if only one w_/b_warrior lef
    if len(board.white) == 0 and len(board.black) >= 2: #if no w_warriors are left
        return -1
    if len(board.black) == 0 and len(board.white) >= 2: #if no b_warriors are left
        return 1

    #otherwise, check if white_win or black_win is satisfied
    for coord in board.white:
        if coord in white_win[0] and coord in white_win[1]:
            return 1
    for coord in board.black:
        if coord in black_win[0] and coord in black_win[1]:
            return -1
    return 0

def result(): #Printing required information per step done by AI
    print("Max Depth: ", maxD)
    print("Nodes Generated: ", Nodes)
    print("Max Pruned: ", maxP)
    print("Min Pruned: ", minP)

def u_eval(board): #return a utility value based on current board
    global u_value #difficulty
    white_win = ['D14','E14']
    black_win = ['D1','E1']

    min_w_insteps = 13 #fastest winning condition
    for coord in board.white:
        if coord in white_win:
            return u_value #player win
        min_w_distance = min(min_w_insteps, 13 - int(coord_decode(coord)/8)) #how close for player to win
    for coord in board.black:
        if coord in black_win:
            return -u_value #AI win
        min_b_distance = min(min_w_insteps, int(coord_decode(coord)/8)) #how close for AI to win

    return u_value*((0.5 * (-1/min_b_distance)) + (0.5 * (1/min_w_distance))) #return score, 50/50 to ensure fairness
    #if two players are equally likely to win, then it would return 0, which is draw.

g = Board() #GAME BOARD
g.print_board() #BASIC DISPLAY

#user input to specify first or second, what level of difficulty
print("Would you like to go first(F) or second(S)? (F/S)")
order = input().upper()
if order == 'F':
    human_num = 1
elif order == 'S':
    human_num = -1
else:
    print("Invalid input, default selection: player goes first!")
    human_num = 1
print("How difficult do you want the game to be? Please enter an integer between 1-3")
level = int(input()) #change u_value based on difficulty to limit nodes generated and how deep the search is
if level == 1:
    u_value = 50
elif level == 2:
    u_value = 100
elif level == 3:
    u_value = 1000
else:
    print("Invalid input, default selection: easy(1)")
    u_value = 50
print("GAME GENERATING...")

successive = False  # if cantering or capturing move

while True:
    maxD = 0 #MaxDepth
    Nodes = 0 #Nodes Generated
    maxP = 0 #MaxNodes Prunes
    minP = 0 #MinNodes Prunes
    start_time = 0 #10sec rules for AB searchW
    depth_limit = level + 3 #difficulty evaluation
    #default depth_limit is 3

    if human_num == 1:
        player_move(g)
        g.print_board()
        while successive:
            print("Successive Moves Activated!")
            player_move(g)
            g.print_board()
            if win(g) != 0:
                break
        if win(g) != 0:
            break
        ai_move(g,ab_search(g,0))
        result()
        g.print_board()
        if win(g) != 0:
            break
    else:
        ai_move(g,ab_search(g,0))
        result()
        g.print_board()
        if win(g) != 0:
            break
        player_move(g)
        g.print_board()
        while successive:
            print("Successive Moves Activated!")
            player_move(g)
            g.print_board()
            if win(g) != 0:
                break
        if win(g) != 0:
            break

if win(g) == 1:
    print("GAME OVER. White has won the game!")
elif win(g) == -1:
    print("GAME OVER. Black has won the game!")
elif win(g) == 2:
    print("GAME OVER. Draw!")
else:
    print("END GAME")